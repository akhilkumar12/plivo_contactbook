$(document).find('#search-panel .submit-search').off('click').on('click', function(e){
  e.stopPropagation();
  console.log('conbsole');
  $(this).closest('#search-panel').find('.search-result-row').remove();
  var cname = $(this).closest('#search-form').find('#search-name').val()
  var cmail = $(this).closest('#search-form').find('#search-email').val()
  var data = {}
  if(cname && cname.length){
    data['name'] = cname
  }
  if(cmail && cmail.length){
    data['email'] = cmail
  }
  // if(Object.keys(data).length == 0){
  //   return
  // }

  var remote_url = 'http://127.0.0.1:8000/contact_book/'+'fetch_contacts/'
  var response = $.ajax({
    //type: "POST",
    url: remote_url,
    data: data,
    dataType: 'JSON',
    timeout: 60000,
    success : function(response, status, xhr){
        if(status == 'error'){
            console.log('error')

        }
        else{
            var res = response;
            var clone_div = $('<div class="search-result-row">'+
                                '<div class="contact_name"></div>'+
                                '<div class="contact_no"></div>'+
                                '<div class="c_email_id"></div>'+
                                '<div class="c_address"></div>'+
                                '<div class="crud_buttons" style="display:none">'+
                                  '<div class="cup cbut">Update</div>'+
                                  '<div class="cdel cbut">Delete</div>'+
                                '</div>'+
                              '</div>')
            $.each(res, function(i,e){
                  var cinfo = clone_div.clone();
                  cinfo.find('.contact_name').text(e.first_name + ' ' + e.last_name)
                  cinfo.find('.contact_no').text(e.phone_no)
                  cinfo.find('.c_email_id').text(e.email_id)
                  cinfo.find('.c_address').text(e.address)
                  $(document).find('#search-panel').append(cinfo)
            })
        }
    }
  })

})


$(document).find('#add-contact .submit-add').off('click').on('click', function(e){
  e.stopPropagation();
  console.log('conbsole');
  var cfname = $(this).closest('#add-contact').find('#add-fname').val()
  var clname = $(this).closest('#add-contact').find('#add-lname').val()
  var cmail = $(this).closest('#add-contact').find('#add-email').val()
  var cnum = $(this).closest('#add-contact').find('#add-number').val()
  var cadd = $(this).closest('#add-contact').find('#add-address').val()
  var data = {}
  if(cfname && cfname.length){
    data['name'] = cfname
  }
  if(clname && clname.length){
    data['last_name'] = clname
  }
  if(cmail && cmail.length){
    data['email'] = cmail
  }
  if(cnum && cnum.length){
    data['phone'] = cnum
  }
  if(cadd && cadd.length){
    data['address'] = cadd
  }
  if(Object.keys(data).length == 0){
    return
  }

  var remote_url = 'http://127.0.0.1:8000/contact_book/'+'edit_contacts/'
  var response = $.ajax({
    //type: "POST",
    url: remote_url,
    data: data,
    dataType: 'JSON',
    timeout: 60000,
    success : function(response, status, xhr){
        if(status == 'error'){
            console.log('error')
            $(document).find('#add-contact .isa_error').show().delay(1000).fadeOut();
        }
        else{
          console.log('success');
          $(document).find('#add-contact .isa_success').text(response['msg']).show().delay(1000).fadeOut();
          $(document).find('#add-contact input').val('')
        }
    },
   error: function(e){
        $(document).find('.isa_error').show().delay(1000).fadeOut();
    }

  })

})




$(document).find('.search-result').off('click').on('click', function(){
  if($(this).find('.crud_buttons').is(':visible')){
      $(this).find('.crud_buttons').hide();
      return;
  }
  $(this).find('.crud_buttons').show();
})