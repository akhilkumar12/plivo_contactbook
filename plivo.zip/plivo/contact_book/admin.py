# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from . models import Contact
# Register your models here.

admin.site.register(Contact)




# user = plivo
# pass = contact@plivo123