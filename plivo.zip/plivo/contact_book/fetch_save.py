from models import Contact
import re

def fetch_data(email,first_name):
	if email:
		match = re.match('^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)$', email)
		if match is None:
			print 'Bad Syntax for email'
			raise ValueError('Bad Syntax for email')
	if first_name and not first_name.isalpha():
		print 'Bad Syntax for first name'
		raise ValueError('Bad Syntax for first name')

	if not email and not first_name:
		data = Contact.objects.filter(active = True).values()
	elif email and not first_name:
		data = Contact.objects.filter(email_id = email, active = True).values()
	elif not email and first_name:
		data = Contact.objects.filter(first_name = first_name, active = True).values()
	else:
		data = Contact.objects.filter(email_id = email, first_name = first_name, active = True).values()

	return data


def update_data(action,email,first_name,last_name,phone,address):
	match = re.match('^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)$', email)
	if match is None:
		print 'Bad Syntax for email'
		raise ValueError('Bad Syntax for email')
	flag = 1
	try:
		cd = Contact.objects.get(email_id = email, active = True)
		print action and cd
		if action == 'add' and cd:
			msg = 'Contact with same email already exists'
			flag = 0
		msg = 'Contact updated successfully'
	except:
		cd = Contact(email_id = email)
		if action == 'update':
			msg = 'Email id changed. Please add this as a new Contact'
			raise ValueError(msg)
		msg = 'Contact created successfully'

	if not flag:
		raise ValueError(msg)
	print "Data here ", email,first_name,last_name,phone,address,action
	if not first_name or not first_name.isalpha():
		print 'Bad Syntax for first name'
		raise ValueError('Bad Syntax for first name')
	if last_name and not last_name.isalpha():
		print 'Bad Syntax for last name'
		raise ValueError('Bad Syntax for last name')
	else:
		last_name = ''
	if phone:
		match = re.match("^[789]\d{9}$",phone)
		if match is None:
			print 'Bad Syntax for phone number'
			raise ValueError('Bad Syntax for phone number')
	cd.first_name = first_name
	cd.last_name = last_name
	cd.phone_no = phone
	cd.address = address
	cd.save()
	return msg



def delete_data(email):
	match = re.match('^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)$', email)
	if match is None:
		print 'Bad Syntax for email'
		raise ValueError('Bad Syntax for email')

	try:
		cd = Contact.objects.get(email_id = email, active = True)
		msg = "Contact Deleted Successfully"
		cd.active = False
		cd.save()
	except:
		msg = "No Such Contact to delete"

	return msg
