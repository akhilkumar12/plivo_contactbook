from django.conf.urls import url,include
from django.contrib import admin
from rest_framework.urlpatterns import format_suffix_patterns
from . import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'fetch_contacts/$', views.GetContactData.as_view()),
    url(r'edit_contacts/$', views.UpdateContactData.as_view()),
    url(r'delete_contacts/$', views.DeleteContactData.as_view()),
]


urlpatterns = format_suffix_patterns(urlpatterns)