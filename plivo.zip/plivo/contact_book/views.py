# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render,get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.http import HttpResponse
from django.db.models import Sum
from .serializers import ContactSerializer

from fetch_save import fetch_data,update_data,delete_data

def index(request):
	return render(request, 'contact_book/contactbook.htm')
	# html = "<h2>Welcome to the new Yellow Pages</h2>"
	# return HttpResponse(html)


def default_response():
    return {
        'result':[],
        'counter':0,
        'response':{
                'status':False,
                'msg':[]
        }
    }



class GetContactData(APIView):

	def get(self,request):
		email = request.query_params.get('email')
		first_name = request.query_params.get('name')
		response = default_response()
		# result = Contact.objects.filter(email_id = email, first_name = first_name).values()
		result = fetch_data(email,first_name)
		# serializers = ContactSerializer(result,many=True)
		response['result'] = result

		return Response(result)



class UpdateContactData(APIView):

	def get(self,request):
		action = request.query_params.get('action')
		email = request.query_params.get('email')
		if not email:
			return Response({"msg" : "Enter an email id"})
		first_name = request.query_params.get('name')
		last_name = request.query_params.get('last_name')
		phone = request.query_params.get('phone')
		address = request.query_params.get('address')

		print "Data here ", email,first_name,last_name,phone,address,action
		
		response = default_response()
		result = update_data(action,email,first_name,last_name,phone,address)
		serializers = ContactSerializer(result,many=True)
		# response['result'] = result

		return Response(result)




class DeleteContactData(APIView):

	def get(self,request):
		email = request.query_params.get('email')
		if not email:
			return Response({"msg" : "Enter an email id"})

		response = default_response()
		# result = Contact.objects.filter(email_id = email, first_name = first_name).values()
		result = delete_data(email)
		# serializers = ContactSerializer(result,many=True)
		response['result'] = result

		return Response(result)
