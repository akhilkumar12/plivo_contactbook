# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Contact(models.Model):
	email_id = models.CharField(max_length = 50, null=False, blank=False)
	first_name = models.CharField(max_length = 20, null=False, blank=False)
	last_name = models.CharField(max_length = 20, null=True, blank=True)
	phone_no = models.CharField(max_length = 15, null=False, blank=True)
	address = models.CharField(max_length = 200, null=False, blank=True)
	active = models.BooleanField(default=True)

	def __str__(self):
		return self.email_id