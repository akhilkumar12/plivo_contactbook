$(document).find('#search-panel .submit-search').off('click').on('click', function(e){
  e.stopPropagation();
  console.log('conbsole');
  $(this).closest('#search-panel').find('.search-result-row').remove();
  var cname = $(this).closest('#search-form').find('#search-name').val()
  var cmail = $(this).closest('#search-form').find('#search-email').val()
  var data = {}
  if(cname && cname.length){
    data['name'] = cname
  }
  if(cmail && cmail.length){
    data['email'] = cmail
  }
  // if(Object.keys(data).length == 0){
  //   return
  // }

  var remote_url = 'http://127.0.0.1:8000/contact_book/'+'fetch_contacts/'
  var response = $.ajax({
    //type: "POST",
    url: remote_url,
    data: data,
    dataType: 'JSON',
    timeout: 60000,
    success : function(response, status, xhr){
        if(status == 'error'){
            console.log('error')

        }
        else{
            var res = response;
            var clone_div = $('<div class="search-result-row">'+
                                '<div class="contact_name row_det"></div>'+
                                '<div class="contact_no row_det"></div>'+
                                '<div class="c_email_id row_det_no_edit"></div>'+
                                '<div class="c_address row_det"></div>'+
                                '<div class="crud_buttons" style="display:none">'+
                                  '<div class="cedit cbut">Edit</div>'+
                                  '<div class="cdel cbut">Delete</div>'+
                                '</div>'+
                                '<div class="cbut cup" style="display:none">Update</div>'+
                              '</div>')
            $.each(res, function(i,e){
                  var cinfo = clone_div.clone();
                  cinfo.find('.contact_name').text(e.first_name + ' ' + e.last_name)
                  cinfo.find('.contact_no').text(e.phone_no)
                  cinfo.find('.c_email_id').text(e.email_id)
                  cinfo.find('.c_address').text(e.address)
                  $(document).find('#search-panel').append(cinfo)
            })
        }
    }
  })

})


$(document).find('#add-contact .submit-add').off('click').on('click', function(e){
  e.stopPropagation();
  console.log('conbsole');
  var cfname = $(this).closest('#add-contact').find('#add-fname').val()
  var clname = $(this).closest('#add-contact').find('#add-lname').val()
  var cmail = $(this).closest('#add-contact').find('#add-email').val()
  var cnum = $(this).closest('#add-contact').find('#add-number').val()
  var cadd = $(this).closest('#add-contact').find('#add-address').val()
  var data = {}
  if(cfname && cfname.length){
    data['name'] = cfname
  }
  if(clname && clname.length){
    data['last_name'] = clname
  }
  if(cmail && cmail.length){
    data['email'] = cmail
  }
  if(cnum && cnum.length){
    data['phone'] = cnum
  }
  if(cadd && cadd.length){
    data['address'] = cadd
  }
  if(Object.keys(data).length == 0){
    alert("All fields empty")
    return
  }
  data['action'] = 'add'

  var remote_url = 'http://127.0.0.1:8000/contact_book/'+'edit_contacts/'
  var response = $.ajax({
    //type: "POST",
    url: remote_url,
    data: data,
    dataType: 'JSON',
    timeout: 60000,
    success : function(response, status, xhr){
        if(status == 'error'){
            console.log('error')
            $(document).find('#add-contact .isa_error').show().delay(1000).fadeOut();
        }
        else{
          console.log('success');
          $(document).find('#add-contact .isa_success').text(response['msg']).show().delay(1000).fadeOut();
          $(document).find('#add-contact input').val('')
        }
    },
   error: function(e){
        $(document).find('#add-contact .isa_error').show().delay(1000).fadeOut();
    }

  })

})




$(document).on('click','.search-result-row', function(){
  if($(this).hasClass('no_up')){
    return;
  }
  if($(this).find('.crud_buttons').is(':visible')){
      $(this).find('.crud_buttons').hide();
      return;
  }
  $(this).find('.crud_buttons').show();
})


$(document).on('click', '.search-result-row .cdel', function(e){
  e.stopPropagation();
  var mail = $(this).closest('.search-result-row').find('.c_email_id').text();
  var data = {'email': mail}
  var remote_url = 'http://127.0.0.1:8000/contact_book/'+'delete_contacts/'
  var elem = $(this)
  var response = $.ajax({
    //type: "POST",
    url: remote_url,
    data: data,
    dataType: 'JSON',
    timeout: 60000,
    success : function(response, status, xhr){
        if(status == 'error'){
            console.log('error')
            // $(document).find('#add-contact .isa_error').show().delay(1000).fadeOut();
        }
        else{
          console.log('success');
          elem.closest('.search-result-row').remove();
          // $(document).find('#add-contact .isa_success').text(response['msg']).show().delay(1000).fadeOut();
          // $(document).find('#add-contact input').val('')
        }
    },
   error: function(e){
        console.log('error')
        alert("Invalid email")
        // $(document).find('.isa_error').show().delay(1000).fadeOut();
    }

  })

})


$(document).on('click', '.search-result-row .editable', function(e){
  e.stopPropagation();
})

$(document).on('click', '.search-result-row .cedit', function(e){
  e.stopPropagation();
  $(this).closest('.crud_buttons').hide()
  $(this).closest('.search-result-row').find('.row_det').attr('contenteditable', "true").addClass('editable');
  $(this).closest('.search-result-row').addClass('no_up');
  $(this).closest('.search-result-row').find('.cup').show()
})


$(document).on('click', '.search-result-row .cup', function(e){
  e.stopPropagation();
  var cfname = $(this).closest('.search-result-row').find('.contact_name').text().split(' ')[0]
  var clname_temp = $(this).closest('.search-result-row').find('.contact_name').text().split(' ')[1] 
  var clname = '';
  if(clname_temp && clname_temp.length){
    clname = clname_temp;
  }
  var cnum = $(this).closest('.search-result-row').find('.contact_no').text();
  var cmail = $(this).closest('.search-result-row').find('.c_email_id').text();
  var cadd = $(this).closest('.search-result-row').find('.c_address').text();

  var data = {}
  if(cfname && cfname.length){
    data['name'] = cfname
  }
  if(clname && clname.length){
    data['last_name'] = clname
  }
  if(cmail && cmail.length){
    data['email'] = cmail
  }
  else{
    alert("No email id entered");
    return 
  }
  if(cnum && cnum.length){
    data['phone'] = cnum
  }
  if(cadd && cadd.length){
    data['address'] = cadd
  }
  data['action'] = 'update'
  var elem = $(this);

  var remote_url = 'http://127.0.0.1:8000/contact_book/'+'edit_contacts/'
  var response = $.ajax({
    //type: "POST",
    url: remote_url,
    data: data,
    dataType: 'JSON',
    timeout: 60000,
    success : function(response, status, xhr){
        if(status == 'error'){
            console.log('error')
            // $(document).find('#add-contact .isa_error').show().delay(1000).fadeOut();
        }
        else{
          console.log('success');
          elem.closest('.search-result-row').find('.row_det').attr('contenteditable', false).removeClass('editable');
          elem.closest('.search-result-row').find('.cup').hide()
          elem.closest('.search-result-row').find('.crud_buttons').show()
          elem.closest('.search-result-row').removeClass('no_up');
          // $(document).find('#add-contact .isa_success').text(response['msg']).show().delay(1000).fadeOut();
          // $(document).find('#add-contact input').val('')
        }
    },
   error: function(e){
        alert("Invalid Entry")
        $(document).find('.isa_error').show().delay(1000).fadeOut();
    }

  })
  

  // $(this)

})

