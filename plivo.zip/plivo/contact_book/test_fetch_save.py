import unittest
from fetch_save import fetch_data,update_data,delete_data


class TestFetchData(unittest.TestCase):

	def test_fetch_data(self):
		data = fetch_data('akhil@gmail.com','akhil')
		data = [i for i in data]
		self.assertEqual(type(data),type(''))
		if data:
			self.assertEqual(type(data[0]),type([]))
		email = 'akhil@gmail@.com'
		self.assertRaises(ValueError,fetch_data,email,'akhil')
		
		email = 'akhil@gmail.yahoo.com'
		self.assertRaises(ValueError,fetch_data,email,'akhil')
		
		name = 'akhil kumar'
		self.assertRaises(ValueError,fetch_data,'akhil@gmail.com',name)
		
		name = 'akhil12w12asd'
		self.assertRaises(ValueError,fetch_data,'akhil@gmail.com',name)


class TestUpdateData(unittest.TestCase):

	def test_update_data(self):
		email = 'akhil@gmail.com'
		name = 'Akhil'
		last_name = 'Kumar'
		phone = '9650038097'
		address = 'Rohini,Delhi'
		msg = update_data(email,name,last_name,phone,address)
		self.assertEqual(msg,'Contact updated successfully')

		self.assertRaises(ValueError,update_data,'akhil@gmail.yahoo.com',name,last_name,phone,address)
		self.assertRaises(ValueError,update_data,email,'Akhil 2 kumar',last_name,phone,address)
		self.assertRaises(ValueError,update_data,email,name,'kumar 12 kumar',phone,address)
		self.assertRaises(ValueError,update_data,email,name,last_name,'012038907',address)



class TestDeleteData(unittest.TestCase):

	def test_delete_data(self):
		email = 'aditi@gmail.com'
		msg = delete_data(email)
		self.assertTrue(msg=='Contact Deleted Successfully' or msg=='No Such Contact to delete')
		self.assertRaises(ValueError,delete_data,'akhil@gmail.yahoo.com')
		self.assertRaises(ValueError,delete_data,'akhil@gmail.@com')



if __name__ == "__main__":
    unittest.main()
