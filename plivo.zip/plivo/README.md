Problem Statement:

Contact book
• Develop a suite of CRUD APIs for a contact book app
• Each contact should have an unique email address
• APIs should support adding/editing/deleting contacts
• Allow searching by name and email address
• Search should support pagination and should return 10 items by default per invocation
• Add unit tests and Integration tests for each functionality.
• Add basic authentication for the app. Use environment variables or basic auth(for rest APIs)
• Code should scale out for millions of contacts per contact book


This project is made in python using Django framework.

Start by installing django-framewoerk and rest api framework on your system.
pip install django
pip install djangorestframework

This contact book app consists of all CRUD(Create, Read, Update and Delete) APIs and a few other APIs

API List:
	1. /contact_book/fetch_contacts/
	2. /contact_book/edit_contacts/
	3. /contact_book/delete_contacts/
	4. /admin/
	5. /api/token/
	6. /api/token/refresh/

1. /contact_book/fetch_contacts/ API fetches all the data in database as its response.
	To get contact details for a particular name or email-id, send email or name or both as a parameter in API.
	Eg: /contact_book/fetch_contacts/?name=Akhil&email=akhil@gmail.com : will fetch contact details of person named Akhil having email id as akhil@gmail.com

2. /contact_book/edit_contacts/ API provides two different functionalities. 1 is update functionality and other is create functionality.
	To create a new contact or to update an existing one: Send all the contact details as parameters to the API and a variable named action='add' for add
	functionality or action='update' for update functionality.
	Eg: contact_book/edit_contacts/?email=rahul@gmail.com&name=rahul&last_name=sharma&phone=9876123450&address=pune&action=add : will add the following details in contact book
		contact_book/edit_contacts/?email=rahul@gmail.com&name=rahul&last_name=sharma&phone=9876123450&address=delhi&action=add : will update the details of the existing contact with email as search key.

3. /contact_book/delete_contacts/ API deletes a particular entry from the contact book. 
	To delete a contact send email of the contact as the parameter in API.
	Eg: /contact_book/delete_contacts/?email=mayank@gmail.com : will delete contact with email = mayank@gmail.com from the database.

4. /admin/ API provides admin access to update and alter the database. username and password for accessing this is mentioned in admin.py file.

5. /api/token/ and /api/token/refresh/ : These two APIs are for getting a new JSON Web Tokens and refreshing them. These are for the basic authentication of the app.




Now to run the app, go the plivo folder where manage.py exists and run from terminal the following command:

python manage.py runserver

Now, go to http://localhost:8000/contact_book/ which is basically the home page of our App.

Here you will see two forms : 
	1. Search Contacts: This allows user to search by email-id or first name or both. To fetch all contacts from DB, just click on submit button without entering any of the two.
	2. Add a new Contact: This allows users to add a new contact which is not currently present in the database.

The edit and delete functionalities are given when user search for a particular contact.
When the search results are shown on the screen, click on any contact you want to edit or delete. Clicking on a search result gives two options as follows:
	1. Edit: Provides the functionality to update the contact details and save the changes to the database using the update button. The email id be the primary key cannot be updated via the asynchronous api.
	2. Delete: Provides the functionality to delete any contact via the delete_contacts api.

So, these are the 4 basic CRUD(Create, Read, Update, Delete) provided to the user.
